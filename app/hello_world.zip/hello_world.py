def lambda_handler(event, context):
    print("Final test for QLR notifications...")
    return 1 / 0